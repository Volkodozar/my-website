import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { 
  Play, 
  Pause, 
  Square, 
  Zap, 
  TrendingUp, 
  Clock,
  Coins,
  Settings,
  Box
} from "lucide-react";
import { formatTimeAgo, formatCurrency } from "@/lib/utils";

export default function MiningSimulation() {
  const [progress, setProgress] = useState(73);
  const [blocksFound, setBlocksFound] = useState(1247);
  const [uptime, setUptime] = useState(260100); // seconds
  const queryClient = useQueryClient();
  const { toast } = useToast();

  // Fetch active mining session
  const { data: session, isLoading } = useQuery({
    queryKey: ["/api/mining/session"],
    refetchInterval: 5000,
  });

  // Start mining mutation
  const startMining = useMutation({
    mutationFn: () => apiRequest("POST", "/api/mining/start", {
      cryptocurrency: "BTC",
      hashrate: 100,
      powerConsumption: 3250,
      electricityCost: 0.12,
    }).then(res => res.json()),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/mining/session"] });
      toast({
        title: "Майнинг запущен",
        description: "Процесс майнинга успешно начат",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Ошибка",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Stop mining mutation
  const stopMining = useMutation({
    mutationFn: () => apiRequest("POST", "/api/mining/stop").then(res => res.json()),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/mining/session"] });
      toast({
        title: "Майнинг остановлен",
        description: "Процесс майнинга завершен",
      });
    },
  });

  // Pause/Resume mining mutation
  const toggleMining = useMutation({
    mutationFn: () => apiRequest("POST", "/api/mining/pause").then(res => res.json()),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/mining/session"] });
    },
  });

  // Update progress mutation
  const updateProgress = useMutation({
    mutationFn: (data: { progress: number; blocksFound?: number; earnings?: string }) =>
      apiRequest("POST", "/api/mining/progress", data).then(res => res.json()),
  });

  // Simulate mining progress
  useEffect(() => {
    if (!session || session.status !== "active") return;

    const interval = setInterval(() => {
      setProgress(prev => {
        const newProgress = prev + Math.random() * 2;
        if (newProgress >= 100) {
          const newBlocksFound = blocksFound + 1;
          setBlocksFound(newBlocksFound);
          
          // Update backend with new block found
          updateProgress.mutate({
            progress: 0,
            blocksFound: newBlocksFound,
            earnings: "0.00034",
          });
          
          toast({
            title: "Блок найден!",
            description: `Block #${Math.floor(Math.random() * 1000000)} успешно добыт`,
          });
          
          return 0;
        }
        
        // Update progress periodically
        if (Math.random() < 0.1) {
          updateProgress.mutate({ progress: Math.floor(newProgress) });
        }
        
        return newProgress;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [session, blocksFound, updateProgress, toast]);

  // Update uptime
  useEffect(() => {
    if (!session || session.status !== "active") return;

    const interval = setInterval(() => {
      setUptime(prev => prev + 1);
    }, 1000);

    return () => clearInterval(interval);
  }, [session]);

  const formatUptime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    return `${hours}ч ${minutes}м`;
  };

  const isActive = session?.status === "active";
  const isPaused = session?.status === "paused";

  if (isLoading) {
    return (
      <div className="max-w-6xl mx-auto">
        <div className="animate-pulse">
          <div className="h-8 bg-slate-700 rounded mb-4"></div>
          <div className="h-64 bg-slate-700 rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto">
      {/* Mining Status Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-slate-400">Статус</span>
              <div className={`w-3 h-3 rounded-full ${
                isActive ? 'bg-crypto-green animate-pulse' : 
                isPaused ? 'bg-yellow-500' : 'bg-red-500'
              }`}></div>
            </div>
            <div className={`font-bold text-lg ${
              isActive ? 'text-crypto-green' : 
              isPaused ? 'text-yellow-500' : 'text-red-500'
            }`}>
              {isActive ? 'Активно' : isPaused ? 'Пауза' : 'Остановлено'}
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="p-6">
            <div className="text-slate-400 mb-2">Хешрейт</div>
            <div className="text-crypto-gold font-bold text-lg">
              {session ? `${session.hashrate} TH/s` : '0 TH/s'}
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="p-6">
            <div className="text-slate-400 mb-2">Найденные блоки</div>
            <div className="text-crypto-green font-bold text-lg">
              {session?.blocksFound || blocksFound}
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="p-6">
            <div className="text-slate-400 mb-2">Время работы</div>
            <div className="text-slate-300 font-bold text-lg">
              {isActive ? formatUptime(uptime) : '0ч 0м'}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Mining Progress */}
      <Card className="bg-slate-800 border-slate-700 mb-8">
        <CardContent className="p-8">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-semibold text-crypto-gold">Прогресс майнинга</h3>
            <div className="flex items-center space-x-2">
              <div className={`w-2 h-2 rounded-full ${
                isActive ? 'bg-crypto-green animate-pulse' : 'bg-slate-500'
              }`}></div>
              <span className={`text-sm ${isActive ? 'text-crypto-green' : 'text-slate-500'}`}>
                {isActive ? 'В процессе' : 'Остановлено'}
              </span>
            </div>
          </div>

          {/* Current Block Progress */}
          <div className="mb-6">
            <div className="flex justify-between text-sm mb-2">
              <span className="text-slate-400">Текущий блок</span>
              <span className="text-slate-300">Block #{Math.floor(Math.random() * 1000000)}</span>
            </div>
            <Progress 
              value={progress} 
              className="h-3 bg-slate-700"
            />
            <div className="text-right text-xs text-slate-400 mt-1">
              {Math.floor(progress)}%
            </div>
          </div>

          {/* Mining Animation */}
          <div className="flex justify-center mb-6">
            <div className="relative">
              <div className={`w-24 h-24 bg-gradient-to-br from-crypto-green to-crypto-gold rounded-full flex items-center justify-center ${
                isActive ? 'animate-mining' : ''
              }`}>
                <Box className="text-slate-950 text-2xl" />
              </div>
              {isActive && (
                <>
                  <div className="absolute -top-2 -right-2 w-6 h-6 bg-crypto-gold rounded-full animate-pulse"></div>
                  <div className="absolute -bottom-2 -left-2 w-4 h-4 bg-crypto-green rounded-full animate-pulse" 
                       style={{animationDelay: '0.5s'}}></div>
                </>
              )}
            </div>
          </div>

          {/* Mining Controls */}
          <div className="flex justify-center space-x-4">
            {!session || session.status === "stopped" ? (
              <Button 
                onClick={() => startMining.mutate()}
                disabled={startMining.isPending}
                className="bg-crypto-green hover:bg-green-600"
              >
                <Play className="mr-2 h-4 w-4" />
                {startMining.isPending ? "Запуск..." : "Начать майнинг"}
              </Button>
            ) : (
              <>
                <Button 
                  onClick={() => toggleMining.mutate()}
                  disabled={toggleMining.isPending}
                  className="bg-crypto-green hover:bg-green-600"
                >
                  {isPaused ? <Play className="mr-2 h-4 w-4" /> : <Pause className="mr-2 h-4 w-4" />}
                  {isPaused ? "Продолжить" : "Пауза"}
                </Button>
                <Button 
                  onClick={() => stopMining.mutate()}
                  disabled={stopMining.isPending}
                  variant="destructive"
                >
                  <Square className="mr-2 h-4 w-4" />
                  Остановить
                </Button>
              </>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Recent Mining Activity */}
      <Card className="bg-slate-800 border-slate-700">
        <CardContent className="p-8">
          <h3 className="text-xl font-semibold text-crypto-gold mb-6">Последняя активность</h3>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-slate-900 rounded-lg">
              <div className="flex items-center space-x-4">
                <div className="w-10 h-10 bg-crypto-green/20 rounded-full flex items-center justify-center">
                  <Box className="text-crypto-green h-5 w-5" />
                </div>
                <div>
                  <div className="font-medium text-slate-200">Блок найден</div>
                  <div className="text-sm text-slate-400">Block #847292 - 2 минуты назад</div>
                </div>
              </div>
              <div className="text-crypto-green font-semibold">+0.00034 BTC</div>
            </div>
            
            <div className="flex items-center justify-between p-4 bg-slate-900 rounded-lg">
              <div className="flex items-center space-x-4">
                <div className="w-10 h-10 bg-crypto-gold/20 rounded-full flex items-center justify-center">
                  <Coins className="text-crypto-gold h-5 w-5" />
                </div>
                <div>
                  <div className="font-medium text-slate-200">Вознаграждение получено</div>
                  <div className="text-sm text-slate-400">Pool reward - 5 минут назад</div>
                </div>
              </div>
              <div className="text-crypto-gold font-semibold">+$47.82</div>
            </div>

            <div className="flex items-center justify-between p-4 bg-slate-900 rounded-lg">
              <div className="flex items-center space-x-4">
                <div className="w-10 h-10 bg-blue-500/20 rounded-full flex items-center justify-center">
                  <Settings className="text-blue-400 h-5 w-5" />
                </div>
                <div>
                  <div className="font-medium text-slate-200">Оборудование подключено</div>
                  <div className="text-sm text-slate-400">Miner-03 - 15 минут назад</div>
                </div>
              </div>
              <div className="text-blue-400 font-semibold">+100 TH/s</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
