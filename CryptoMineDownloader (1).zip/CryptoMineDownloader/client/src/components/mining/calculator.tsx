import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Calculator as CalculatorIcon, Loader2 } from "lucide-react";
import { formatCurrency } from "@/lib/utils";

interface CalculationResult {
  dailyRevenue: string;
  dailyElectricityCost: string;
  dailyProfit: string;
  weeklyProfit: string;
  monthlyProfit: string;
  yearlyProfit: string;
  poolFee: string;
  netProfit: string;
}

export default function Calculator() {
  const [cryptocurrency, setCryptocurrency] = useState("BTC");
  const [hashrate, setHashrate] = useState("100");
  const [powerConsumption, setPowerConsumption] = useState("3250");
  const [electricityCost, setElectricityCost] = useState("0.12");
  const [result, setResult] = useState<CalculationResult | null>(null);
  const [isCalculating, setIsCalculating] = useState(false);
  const { toast } = useToast();

  const handleCalculate = async () => {
    if (!hashrate || !powerConsumption || !electricityCost) {
      toast({
        title: "Ошибка",
        description: "Пожалуйста, заполните все поля",
        variant: "destructive",
      });
      return;
    }

    setIsCalculating(true);
    try {
      const response = await apiRequest("POST", "/api/calculate-profitability", {
        cryptocurrency,
        hashrate: parseFloat(hashrate),
        powerConsumption: parseInt(powerConsumption),
        electricityCost: parseFloat(electricityCost),
      });

      const data = await response.json();
      setResult(data);
    } catch (error) {
      toast({
        title: "Ошибка расчета",
        description: "Не удалось рассчитать прибыльность",
        variant: "destructive",
      });
    } finally {
      setIsCalculating(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <Card className="bg-slate-800 border-slate-700">
        <CardContent className="p-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Calculator Form */}
            <div className="space-y-6">
              <div>
                <Label className="text-slate-300 mb-2">Криптовалюта</Label>
                <Select value={cryptocurrency} onValueChange={setCryptocurrency}>
                  <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-700 border-slate-600">
                    <SelectItem value="BTC">Bitcoin (BTC)</SelectItem>
                    <SelectItem value="ETH">Ethereum (ETH)</SelectItem>
                    <SelectItem value="LTC">Litecoin (LTC)</SelectItem>
                    <SelectItem value="DOGE">Dogecoin (DOGE)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className="text-slate-300 mb-2">Хешрейт (TH/s)</Label>
                <Input
                  type="number"
                  value={hashrate}
                  onChange={(e) => setHashrate(e.target.value)}
                  className="bg-slate-700 border-slate-600 text-white focus:ring-crypto-green"
                />
              </div>

              <div>
                <Label className="text-slate-300 mb-2">Потребление энергии (Вт)</Label>
                <Input
                  type="number"
                  value={powerConsumption}
                  onChange={(e) => setPowerConsumption(e.target.value)}
                  className="bg-slate-700 border-slate-600 text-white focus:ring-crypto-green"
                />
              </div>

              <div>
                <Label className="text-slate-300 mb-2">Стоимость электричества ($/кВт⋅ч)</Label>
                <Input
                  type="number"
                  step="0.01"
                  value={electricityCost}
                  onChange={(e) => setElectricityCost(e.target.value)}
                  className="bg-slate-700 border-slate-600 text-white focus:ring-crypto-green"
                />
              </div>

              <Button 
                onClick={handleCalculate}
                disabled={isCalculating}
                className="w-full bg-crypto-green hover:bg-green-600"
              >
                {isCalculating ? (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  <CalculatorIcon className="mr-2 h-4 w-4" />
                )}
                {isCalculating ? "Расчет..." : "Рассчитать прибыль"}
              </Button>
            </div>

            {/* Results */}
            <div className="space-y-6">
              <Card className="bg-slate-900 border-slate-700">
                <CardContent className="p-6">
                  <h3 className="text-lg font-semibold text-crypto-gold mb-4">Прогнозируемая прибыль</h3>
                  
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-slate-300">В день:</span>
                      <span className="text-crypto-green font-bold text-lg">
                        {result ? formatCurrency(parseFloat(result.dailyProfit)) : "$127.43"}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-slate-300">В неделю:</span>
                      <span className="text-crypto-green font-bold text-lg">
                        {result ? formatCurrency(parseFloat(result.weeklyProfit)) : "$892.01"}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-slate-300">В месяц:</span>
                      <span className="text-crypto-green font-bold text-lg">
                        {result ? formatCurrency(parseFloat(result.monthlyProfit)) : "$3,823.90"}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-slate-300">В год:</span>
                      <span className="text-crypto-green font-bold text-xl">
                        {result ? formatCurrency(parseFloat(result.yearlyProfit)) : "$46,512.95"}
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-slate-900 border-slate-700">
                <CardContent className="p-6">
                  <h3 className="text-lg font-semibold text-crypto-gold mb-4">Детали расчета</h3>
                  
                  <div className="space-y-3 text-sm">
                    <div className="flex justify-between">
                      <span className="text-slate-400">Доход в день:</span>
                      <span className="text-slate-300">
                        {result ? formatCurrency(parseFloat(result.dailyRevenue)) : "$156.78"}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Расходы на электричество:</span>
                      <span className="text-slate-300">
                        {result ? formatCurrency(parseFloat(result.dailyElectricityCost)) : "$29.35"}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Комиссия пула:</span>
                      <span className="text-slate-300">
                        {result ? formatCurrency(parseFloat(result.poolFee)) : "$0.00"}
                      </span>
                    </div>
                    <hr className="border-slate-600" />
                    <div className="flex justify-between font-semibold">
                      <span className="text-slate-300">Чистая прибыль:</span>
                      <span className="text-crypto-green">
                        {result ? formatCurrency(parseFloat(result.netProfit)) : "$127.43"}
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
