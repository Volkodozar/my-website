import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { formatCurrency, formatTimeAgo } from "@/lib/utils";
import { 
  TrendingUp, 
  TrendingDown, 
  Plus, 
  Minus,
  Coins,
  CreditCard,
  Clock
} from "lucide-react";

export default function TransactionHistory() {
  const { data: transactions, isLoading } = useQuery({
    queryKey: ["/api/transactions"],
  });

  const getTransactionIcon = (type: string) => {
    switch (type) {
      case "deposit":
        return <Plus className="text-blue-400 h-5 w-5" />;
      case "withdrawal":
        return <Minus className="text-red-400 h-5 w-5" />;
      case "mining_reward":
        return <Coins className="text-crypto-green h-5 w-5" />;
      default:
        return <CreditCard className="text-slate-400 h-5 w-5" />;
    }
  };

  const getTransactionLabel = (type: string) => {
    switch (type) {
      case "deposit":
        return "Пополнение счета";
      case "withdrawal":
        return "Вывод средств";
      case "mining_reward":
        return "Майнинг-вознаграждение";
      case "fee":
        return "Комиссия";
      default:
        return "Транзакция";
    }
  };

  const getTransactionColor = (type: string) => {
    switch (type) {
      case "deposit":
        return "text-blue-400";
      case "withdrawal":
        return "text-red-400";
      case "mining_reward":
        return "text-crypto-green";
      case "fee":
        return "text-orange-400";
      default:
        return "text-slate-400";
    }
  };

  const getAmountPrefix = (type: string) => {
    return type === "withdrawal" || type === "fee" ? "-" : "+";
  };

  if (isLoading) {
    return (
      <Card className="bg-slate-800 border-slate-700">
        <CardHeader>
          <CardTitle className="text-crypto-gold">История транзакций</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="animate-pulse">
                <div className="flex items-center space-x-4 p-4 bg-slate-900 rounded-lg">
                  <div className="w-10 h-10 bg-slate-700 rounded-full"></div>
                  <div className="flex-1">
                    <div className="h-4 bg-slate-700 rounded w-3/4 mb-2"></div>
                    <div className="h-3 bg-slate-700 rounded w-1/2"></div>
                  </div>
                  <div className="h-4 bg-slate-700 rounded w-16"></div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-slate-800 border-slate-700">
      <CardHeader>
        <CardTitle className="text-crypto-gold">История транзакций</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4 max-h-96 overflow-y-auto">
          {transactions && transactions.length > 0 ? (
            transactions.map((transaction: any) => (
              <div key={transaction.id} className="flex items-center justify-between p-4 bg-slate-900 rounded-lg">
                <div className="flex items-center space-x-4">
                  <div className="w-10 h-10 bg-slate-800 rounded-full flex items-center justify-center">
                    {getTransactionIcon(transaction.type)}
                  </div>
                  <div>
                    <div className="font-medium text-slate-200">
                      {getTransactionLabel(transaction.type)}
                    </div>
                    <div className="text-sm text-slate-400 flex items-center">
                      <Clock className="h-3 w-3 mr-1" />
                      {formatTimeAgo(new Date(transaction.createdAt))}
                      {transaction.status === "pending" && (
                        <span className="ml-2 px-2 py-1 bg-yellow-500/20 text-yellow-500 text-xs rounded">
                          В обработке
                        </span>
                      )}
                    </div>
                  </div>
                </div>
                <div className={`font-semibold ${getTransactionColor(transaction.type)}`}>
                  {getAmountPrefix(transaction.type)}{formatCurrency(parseFloat(transaction.amount))}
                </div>
              </div>
            ))
          ) : (
            <div className="text-center py-8 text-slate-400">
              <CreditCard className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>Транзакции отсутствуют</p>
              <p className="text-sm">Пополните счет или начните майнинг</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
