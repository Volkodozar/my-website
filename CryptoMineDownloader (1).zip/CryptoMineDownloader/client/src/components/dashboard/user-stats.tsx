import { Card, CardContent } from "@/components/ui/card";
import { Wallet, DollarSign, TrendingUp, Users } from "lucide-react";
import { formatCurrency, formatNumber } from "@/lib/utils";
import type { User } from "@shared/schema";

interface UserStatsProps {
  user?: User;
  stats?: {
    totalInvestors: number;
    totalInvested: number;
    totalPaidOut: number;
    averageROI: number;
  };
}

export default function UserStats({ user, stats }: UserStatsProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
      <Card className="bg-slate-800/50 backdrop-blur-sm border-slate-700">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-slate-400">Общий баланс</span>
            <Wallet className="text-crypto-gold h-5 w-5" />
          </div>
          <div className="text-crypto-gold font-bold text-2xl">
            {user ? formatCurrency(parseFloat(user.balance || "0")) : "$0.00"}
          </div>
          <div className="text-crypto-green text-sm">Доступно для инвестиций</div>
        </CardContent>
      </Card>

      <Card className="bg-slate-800/50 backdrop-blur-sm border-slate-700">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-slate-400">Заработано</span>
            <TrendingUp className="text-crypto-green h-5 w-5" />
          </div>
          <div className="text-crypto-green font-bold text-2xl">
            {user ? formatCurrency(parseFloat(user.totalEarned || "0")) : "$0.00"}
          </div>
          <div className="text-slate-400 text-sm">За всё время</div>
        </CardContent>
      </Card>

      <Card className="bg-slate-800/50 backdrop-blur-sm border-slate-700">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-slate-400">Общий объем</span>
            <Users className="text-crypto-green h-5 w-5" />
          </div>
          <div className="text-crypto-green font-bold text-2xl">
            {stats ? formatCurrency(stats.totalInvested) : "$8,247,893"}
          </div>
          <div className="text-slate-400 text-sm">Инвестировано</div>
        </CardContent>
      </Card>

      <Card className="bg-slate-800/50 backdrop-blur-sm border-slate-700">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-slate-400">Средняя ROI</span>
            <DollarSign className="text-crypto-green h-5 w-5" />
          </div>
          <div className="text-crypto-green font-bold text-2xl">
            {stats ? `${stats.averageROI}%` : "18.5%"}
          </div>
          <div className="text-slate-400 text-sm">Годовая доходность</div>
        </CardContent>
      </Card>
    </div>
  );
}
