import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useLocation } from "wouter";
import { CreditCard, ArrowUp, Loader2 } from "lucide-react";
import type { User } from "@shared/schema";

interface BalanceManagementProps {
  user?: User;
}

export default function BalanceManagement({ user }: BalanceManagementProps) {
  const [depositAmount, setDepositAmount] = useState("");
  const [withdrawAmount, setWithdrawAmount] = useState("");
  const [withdrawMethod, setWithdrawMethod] = useState("bitcoin");
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const withdrawMutation = useMutation({
    mutationFn: (data: { amount: number; method: string }) =>
      apiRequest("POST", "/api/withdraw", data).then(res => res.json()),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      toast({
        title: "Заявка на вывод создана",
        description: "Ваша заявка будет обработана в течение 24 часов",
      });
      setWithdrawAmount("");
    },
    onError: (error: any) => {
      toast({
        title: "Ошибка вывода",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleDeposit = () => {
    const amount = parseFloat(depositAmount);
    if (isNaN(amount) || amount < 1) {
      toast({
        title: "Ошибка",
        description: "Минимальная сумма пополнения $1",
        variant: "destructive",
      });
      return;
    }

    if (amount > 10000) {
      toast({
        title: "Ошибка",
        description: "Максимальная сумма пополнения $10,000",
        variant: "destructive",
      });
      return;
    }

    // Navigate to checkout page with amount
    setLocation(`/checkout?amount=${amount}`);
  };

  const handleWithdraw = () => {
    const amount = parseFloat(withdrawAmount);
    if (isNaN(amount) || amount < 50) {
      toast({
        title: "Ошибка",
        description: "Минимальная сумма вывода $50",
        variant: "destructive",
      });
      return;
    }

    if (!user || parseFloat(user.balance) < amount) {
      toast({
        title: "Ошибка",
        description: "Недостаточно средств на балансе",
        variant: "destructive",
      });
      return;
    }

    withdrawMutation.mutate({ amount, method: withdrawMethod });
  };

  const getMethodLabel = (method: string) => {
    switch (method) {
      case "bitcoin": return "Bitcoin адрес";
      case "ethereum": return "Ethereum адрес";
      case "card": return "Банковская карта";
      case "paypal": return "PayPal";
      default: return method;
    }
  };

  return (
    <Card className="bg-slate-800 border-slate-700">
      <CardHeader>
        <CardTitle className="text-crypto-gold">Управление балансом</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Deposit Section */}
        <Card className="bg-slate-900">
          <CardContent className="p-6">
            <h4 className="font-semibold text-slate-200 mb-4">Пополнить счет</h4>
            <div className="space-y-4">
              <div>
                <Label htmlFor="deposit-amount" className="text-slate-300">
                  Сумма в USD (минимум $1)
                </Label>
                <Input
                  id="deposit-amount"
                  type="number"
                  min="1"
                  max="10000"
                  value={depositAmount}
                  onChange={(e) => setDepositAmount(e.target.value)}
                  placeholder="100"
                  className="bg-slate-700 border-slate-600 text-white focus:ring-crypto-green"
                />
              </div>
              <Button 
                onClick={handleDeposit}
                className="w-full bg-crypto-green hover:bg-green-600"
                disabled={!depositAmount}
              >
                <CreditCard className="mr-2 h-4 w-4" />
                Пополнить через Stripe
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Withdrawal Section */}
        <Card className="bg-slate-900">
          <CardContent className="p-6">
            <h4 className="font-semibold text-slate-200 mb-4">Вывод средств</h4>
            <div className="space-y-4">
              <div>
                <Label htmlFor="withdraw-amount" className="text-slate-300">
                  Сумма к выводу (минимум $50)
                </Label>
                <Input
                  id="withdraw-amount"
                  type="number"
                  min="50"
                  max={user ? parseFloat(user.balance) : 0}
                  value={withdrawAmount}
                  onChange={(e) => setWithdrawAmount(e.target.value)}
                  placeholder="50"
                  className="bg-slate-700 border-slate-600 text-white focus:ring-crypto-green"
                />
                <p className="text-xs text-slate-400 mt-1">
                  Доступно: ${user ? parseFloat(user.balance).toFixed(2) : "0.00"}
                </p>
              </div>
              
              <div>
                <Label className="text-slate-300">Способ вывода</Label>
                <Select value={withdrawMethod} onValueChange={setWithdrawMethod}>
                  <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-700 border-slate-600">
                    <SelectItem value="bitcoin">Bitcoin адрес</SelectItem>
                    <SelectItem value="ethereum">Ethereum адрес</SelectItem>
                    <SelectItem value="card">Банковская карта</SelectItem>
                    <SelectItem value="paypal">PayPal</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <Button 
                onClick={handleWithdraw}
                disabled={withdrawMutation.isPending || !withdrawAmount}
                className="w-full bg-crypto-gold hover:bg-yellow-600 text-crypto-gold-foreground"
              >
                {withdrawMutation.isPending ? (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  <ArrowUp className="mr-2 h-4 w-4" />
                )}
                {withdrawMutation.isPending ? "Обработка..." : "Вывести средства"}
              </Button>
            </div>
          </CardContent>
        </Card>
      </CardContent>
    </Card>
  );
}
