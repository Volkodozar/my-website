import { Box, Twitter, MessageCircle, Users } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-slate-900 border-t border-slate-800 py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <Box className="text-crypto-green text-2xl" />
              <span className="text-xl font-bold gradient-text">CryptoMine</span>
            </div>
            <p className="text-slate-400 mb-4">
              Ведущая платформа для профессионального майнинга криптовалют с передовыми технологиями и максимальной прибыльностью.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-slate-400 hover:text-crypto-green transition-colors">
                <Twitter className="text-xl" />
              </a>
              <a href="#" className="text-slate-400 hover:text-crypto-green transition-colors">
                <MessageCircle className="text-xl" />
              </a>
              <a href="#" className="text-slate-400 hover:text-crypto-green transition-colors">
                <Users className="text-xl" />
              </a>
            </div>
          </div>

          <div>
            <h3 className="font-semibold text-crypto-gold mb-4">Продукты</h3>
            <ul className="space-y-2 text-slate-400">
              <li><a href="#" className="hover:text-crypto-green transition-colors">Bitcoin майнинг</a></li>
              <li><a href="#" className="hover:text-crypto-green transition-colors">Ethereum майнинг</a></li>
              <li><a href="#" className="hover:text-crypto-green transition-colors">Облачный майнинг</a></li>
              <li><a href="#" className="hover:text-crypto-green transition-colors">ASIC майнеры</a></li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold text-crypto-gold mb-4">Поддержка</h3>
            <ul className="space-y-2 text-slate-400">
              <li><a href="#" className="hover:text-crypto-green transition-colors">Центр помощи</a></li>
              <li><a href="#" className="hover:text-crypto-green transition-colors">Документация API</a></li>
              <li><a href="#" className="hover:text-crypto-green transition-colors">Статус системы</a></li>
              <li><a href="#" className="hover:text-crypto-green transition-colors">Связаться с нами</a></li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold text-crypto-gold mb-4">Компания</h3>
            <ul className="space-y-2 text-slate-400">
              <li><a href="#" className="hover:text-crypto-green transition-colors">О нас</a></li>
              <li><a href="#" className="hover:text-crypto-green transition-colors">Карьера</a></li>
              <li><a href="#" className="hover:text-crypto-green transition-colors">Блог</a></li>
              <li><a href="#" className="hover:text-crypto-green transition-colors">Пресс-кит</a></li>
            </ul>
          </div>
        </div>

        <div className="border-t border-slate-800 mt-8 pt-8 text-center text-slate-400">
          <p>&copy; 2024 CryptoMine Platform. Все права защищены.</p>
        </div>
      </div>
    </footer>
  );
}
