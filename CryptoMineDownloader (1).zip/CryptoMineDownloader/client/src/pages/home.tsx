import { useState, useEffect } from "react";
import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import UserStats from "@/components/dashboard/user-stats";
import BalanceManagement from "@/components/dashboard/balance-management";
import TransactionHistory from "@/components/dashboard/transaction-history";
import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { formatCurrency, formatNumber } from "@/lib/utils";
import { TrendingUp, DollarSign, Calendar, Award, Timer, Percent } from "lucide-react";

export default function Home() {
  const { user } = useAuth();
  const [activeSection, setActiveSection] = useState("home");
  const [selectedPlan, setSelectedPlan] = useState("");
  const [investmentAmount, setInvestmentAmount] = useState("");
  const [calculationResult, setCalculationResult] = useState<any>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: stats } = useQuery({
    queryKey: ["/api/investment-stats"],
  });

  const { data: plans } = useQuery({
    queryKey: ["/api/investment-plans"],
  });

  const { data: investments } = useQuery({
    queryKey: ["/api/investments"],
  });

  const handleLogout = () => {
    window.location.href = "/api/logout";
  };

  const scrollToSection = (sectionId: string) => {
    setActiveSection(sectionId);
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // Calculate investment return
  const calculateInvestment = async () => {
    if (!selectedPlan || !investmentAmount) return;

    try {
      const response = await apiRequest("POST", "/api/calculate-investment", {
        planId: parseInt(selectedPlan),
        amount: parseFloat(investmentAmount)
      });
      const data = await response.json();
      setCalculationResult(data);
    } catch (error) {
      console.error("Calculation error:", error);
    }
  };

  // Create investment mutation
  const createInvestment = useMutation({
    mutationFn: (data: { planId: number; amount: number }) =>
      apiRequest("POST", "/api/investments", data).then(res => res.json()),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/investments"] });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      toast({
        title: "Инвестиция создана",
        description: "Ваша инвестиция успешно активирована",
      });
      setSelectedPlan("");
      setInvestmentAmount("");
      setCalculationResult(null);
    },
    onError: (error: any) => {
      toast({
        title: "Ошибка инвестиции",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleInvest = () => {
    if (!selectedPlan || !investmentAmount) {
      toast({
        title: "Ошибка",
        description: "Выберите план и укажите сумму",
        variant: "destructive",
      });
      return;
    }

    createInvestment.mutate({
      planId: parseInt(selectedPlan),
      amount: parseFloat(investmentAmount)
    });
  };

  // Set up intersection observer to track active section
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setActiveSection(entry.target.id);
          }
        });
      },
      { threshold: 0.3 }
    );

    const sections = document.querySelectorAll("section[id]");
    sections.forEach((section) => observer.observe(section));

    return () => observer.disconnect();
  }, []);

  // Auto-calculate when plan or amount changes
  useEffect(() => {
    if (selectedPlan && investmentAmount) {
      calculateInvestment();
    }
  }, [selectedPlan, investmentAmount]);

  const selectedPlanData = plans?.find((p: any) => p.id === parseInt(selectedPlan));

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100">
      <Header 
        user={user} 
        onLogout={handleLogout} 
        activeSection={activeSection}
        onNavigate={scrollToSection}
      />
      
      {/* Hero Section */}
      <section id="home" className="py-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-slate-950 to-slate-900"></div>
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-crypto-green rounded-full blur-3xl animate-float"></div>
          <div className="absolute bottom-1/4 right-1/4 w-48 h-48 bg-crypto-gold rounded-full blur-3xl animate-float" style={{animationDelay: '1s'}}></div>
        </div>
        
        <div className="container mx-auto px-4 relative z-10">
          <div className="text-center max-w-4xl mx-auto">
            <h1 className="text-5xl md:text-7xl font-bold mb-6 gradient-text">
              Добро пожаловать, {user?.firstName || 'Инвестор'}!
            </h1>
            <p className="text-xl text-slate-300 mb-8 leading-relaxed">
              Управляйте своим инвестиционным портфолио и получайте стабильный доход каждый день.
            </p>
            
            <UserStats user={user} stats={stats} />
          </div>
        </div>
      </section>

      {/* Investment Calculator & Creator */}
      <section id="invest" className="py-16 bg-slate-900/50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold mb-4 text-crypto-green">Создать инвестицию</h2>
            <p className="text-slate-300 text-lg">Выберите план и сумму для начала инвестирования</p>
          </div>

          <div className="max-w-4xl mx-auto">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Investment Form */}
              <Card className="bg-slate-800 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-crypto-gold">Новая инвестиция</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div>
                    <Label className="text-slate-300 mb-2">Инвестиционный план</Label>
                    <Select value={selectedPlan} onValueChange={setSelectedPlan}>
                      <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                        <SelectValue placeholder="Выберите план" />
                      </SelectTrigger>
                      <SelectContent className="bg-slate-700 border-slate-600">
                        {plans?.map((plan: any) => (
                          <SelectItem key={plan.id} value={plan.id.toString()}>
                            {plan.name} - {plan.dailyPercent}% в день
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {selectedPlanData && (
                      <div className="mt-2 text-sm text-slate-400">
                        Сумма: ${formatNumber(selectedPlanData.minAmount)} - ${formatNumber(selectedPlanData.maxAmount)}
                      </div>
                    )}
                  </div>

                  <div>
                    <Label className="text-slate-300 mb-2">Сумма инвестиции ($)</Label>
                    <Input
                      type="number"
                      value={investmentAmount}
                      onChange={(e) => setInvestmentAmount(e.target.value)}
                      placeholder="500"
                      className="bg-slate-700 border-slate-600 text-white focus:ring-crypto-green"
                    />
                    <div className="mt-1 text-sm text-slate-400">
                      Доступно: ${user ? parseFloat(user.balance).toFixed(2) : "0.00"}
                    </div>
                  </div>

                  <Button 
                    onClick={handleInvest}
                    disabled={createInvestment.isPending || !selectedPlan || !investmentAmount}
                    className="w-full bg-crypto-green hover:bg-green-600"
                  >
                    {createInvestment.isPending ? "Создание..." : "Инвестировать"}
                  </Button>
                </CardContent>
              </Card>

              {/* Investment Calculation */}
              <Card className="bg-slate-800 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-crypto-gold">Расчет доходности</CardTitle>
                </CardHeader>
                <CardContent>
                  {calculationResult ? (
                    <div className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div className="text-center p-4 bg-slate-900 rounded-lg">
                          <div className="text-crypto-green text-xl font-bold">
                            ${calculationResult.dailyProfit}
                          </div>
                          <div className="text-slate-400 text-sm">Ежедневно</div>
                        </div>
                        <div className="text-center p-4 bg-slate-900 rounded-lg">
                          <div className="text-crypto-gold text-xl font-bold">
                            ${calculationResult.totalProfit}
                          </div>
                          <div className="text-slate-400 text-sm">Общая прибыль</div>
                        </div>
                      </div>
                      
                      <div className="text-center p-4 bg-slate-900 rounded-lg">
                        <div className="text-crypto-green text-2xl font-bold">
                          ${calculationResult.totalReturn}
                        </div>
                        <div className="text-slate-400">Общий возврат</div>
                      </div>

                      <div className="text-center p-4 bg-slate-900 rounded-lg">
                        <div className="text-crypto-gold text-xl font-bold">
                          {calculationResult.roi}%
                        </div>
                        <div className="text-slate-400">ROI</div>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-8 text-slate-400">
                      <DollarSign className="h-12 w-12 mx-auto mb-4 opacity-50" />
                      <p>Выберите план и сумму для расчета</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Active Investments */}
      <section id="investments" className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold mb-4 text-crypto-gold">Мои инвестиции</h2>
            <p className="text-slate-300 text-lg">Отслеживайте доходность ваших активных инвестиций</p>
          </div>

          <div className="max-w-6xl mx-auto">
            {investments && investments.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {investments.map((investment: any) => {
                  const plan = plans?.find((p: any) => p.id === investment.planId);
                  const daysLeft = Math.ceil(
                    (new Date(investment.expiresAt).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24)
                  );
                  
                  return (
                    <Card key={investment.id} className="bg-slate-800 border-slate-700">
                      <CardHeader>
                        <CardTitle className="text-crypto-gold">{plan?.name}</CardTitle>
                        <div className="text-2xl font-bold text-crypto-green">
                          ${parseFloat(investment.amount).toFixed(2)}
                        </div>
                      </CardHeader>
                      <CardContent className="space-y-3">
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-slate-400">Ежедневно:</span>
                          <span className="text-crypto-green font-semibold flex items-center">
                            <Percent className="h-4 w-4 mr-1" />
                            {investment.dailyPercent}%
                          </span>
                        </div>
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-slate-400">Заработано:</span>
                          <span className="text-crypto-gold font-semibold">
                            ${parseFloat(investment.totalEarned).toFixed(2)}
                          </span>
                        </div>
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-slate-400">Осталось дней:</span>
                          <span className="text-slate-300 font-semibold flex items-center">
                            <Timer className="h-4 w-4 mr-1" />
                            {daysLeft > 0 ? daysLeft : 0}
                          </span>
                        </div>
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-slate-400">Статус:</span>
                          <span className={`font-semibold ${
                            investment.status === 'active' ? 'text-crypto-green' : 'text-slate-400'
                          }`}>
                            {investment.status === 'active' ? 'Активно' : 'Завершено'}
                          </span>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-12">
                <TrendingUp className="h-16 w-16 mx-auto mb-4 text-slate-600" />
                <h3 className="text-xl text-slate-400 mb-2">Инвестиции отсутствуют</h3>
                <p className="text-slate-500">Создайте свою первую инвестицию выше</p>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* User Dashboard */}
      <section id="dashboard" className="py-16 bg-slate-900/50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold mb-4 text-crypto-green">Панель управления</h2>
            <p className="text-slate-300 text-lg">Управляйте балансом и отслеживайте транзакции</p>
          </div>

          <div className="max-w-6xl mx-auto">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <BalanceManagement user={user} />
              <TransactionHistory />
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
