import { useState } from "react";
import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { formatNumber, formatCurrency } from "@/lib/utils";
import { TrendingUp, Shield, Clock, DollarSign, Users, Award } from "lucide-react";

export default function Landing() {
  const { data: stats } = useQuery({
    queryKey: ["/api/investment-stats"],
  });

  const { data: plans } = useQuery({
    queryKey: ["/api/investment-plans"],
  });

  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100">
      <Header onLogin={handleLogin} />
      
      {/* Hero Section */}
      <section id="home" className="py-20 relative overflow-hidden">
        {/* Animated Background */}
        <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-slate-950 to-slate-900"></div>
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-crypto-green rounded-full blur-3xl animate-float"></div>
          <div className="absolute bottom-1/4 right-1/4 w-48 h-48 bg-crypto-gold rounded-full blur-3xl animate-float" style={{animationDelay: '1s'}}></div>
        </div>
        
        <div className="container mx-auto px-4 relative z-10">
          <div className="text-center max-w-4xl mx-auto">
            <h1 className="text-5xl md:text-7xl font-bold mb-6 gradient-text">
              Инвестиции в криптовалюту
            </h1>
            <p className="text-xl text-slate-300 mb-8 leading-relaxed">
              Получайте стабильный пассивный доход от инвестиций в криптовалюту. 
              Надежные депозитные планы с гарантированной доходностью от 1.2% до 2.2% в день.
            </p>
            
            <div className="flex flex-col md:flex-row gap-4 justify-center mb-12">
              <Button 
                size="lg" 
                className="bg-crypto-green hover:bg-green-600 px-8 py-4 text-lg font-semibold transform hover:scale-105 transition-all"
                onClick={handleLogin}
              >
                <TrendingUp className="mr-2 h-5 w-5" />
                Начать инвестировать
              </Button>
              <Button 
                size="lg" 
                variant="outline"
                className="border-crypto-gold text-crypto-gold hover:bg-crypto-gold hover:text-crypto-gold-foreground px-8 py-4 text-lg font-semibold"
                onClick={() => scrollToSection('plans')}
              >
                <DollarSign className="mr-2 h-5 w-5" />
                Посмотреть тарифы
              </Button>
            </div>

            {/* Live Stats */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6 max-w-5xl mx-auto">
              <Card className="bg-slate-800/50 backdrop-blur-sm border-slate-700">
                <CardContent className="p-6 text-center">
                  <div className="text-crypto-green text-2xl font-bold">
                    {stats ? formatNumber(stats.totalInvestors) : "12,847"}
                  </div>
                  <div className="text-slate-400">Инвесторов</div>
                </CardContent>
              </Card>
              <Card className="bg-slate-800/50 backdrop-blur-sm border-slate-700">
                <CardContent className="p-6 text-center">
                  <div className="text-crypto-gold text-2xl font-bold">
                    {stats ? formatCurrency(stats.totalInvested) : "$8,247,893"}
                  </div>
                  <div className="text-slate-400">Инвестировано</div>
                </CardContent>
              </Card>
              <Card className="bg-slate-800/50 backdrop-blur-sm border-slate-700">
                <CardContent className="p-6 text-center">
                  <div className="text-crypto-green text-2xl font-bold">
                    {stats ? formatCurrency(stats.totalPaidOut) : "$1,247,893"}
                  </div>
                  <div className="text-slate-400">Выплачено</div>
                </CardContent>
              </Card>
              <Card className="bg-slate-800/50 backdrop-blur-sm border-slate-700">
                <CardContent className="p-6 text-center">
                  <div className="text-crypto-gold text-2xl font-bold">
                    {stats ? `${stats.averageROI}%` : "18.5%"}
                  </div>
                  <div className="text-slate-400">Средняя ROI</div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Investment Plans */}
      <section id="plans" className="py-16 bg-slate-900/50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold mb-4 text-crypto-green">Инвестиционные планы</h2>
            <p className="text-slate-300 text-lg">Выберите план, который подходит именно вам</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 max-w-7xl mx-auto">
            {plans?.map((plan: any) => (
              <Card key={plan.id} className="bg-slate-800 border-slate-700 hover:border-crypto-green transition-colors">
                <CardHeader>
                  <CardTitle className="text-crypto-gold text-xl">{plan.name}</CardTitle>
                  <div className="text-3xl font-bold text-crypto-green">
                    {plan.dailyPercent}%
                    <span className="text-sm text-slate-400 font-normal">/день</span>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="text-slate-300">
                    <div className="flex justify-between">
                      <span>Минимум:</span>
                      <span className="font-semibold">${formatNumber(plan.minAmount)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Максимум:</span>
                      <span className="font-semibold">${formatNumber(plan.maxAmount)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Срок:</span>
                      <span className="font-semibold">{plan.termDays} дней</span>
                    </div>
                  </div>
                  <p className="text-slate-400 text-sm">{plan.description}</p>
                  <Button 
                    className="w-full bg-crypto-green hover:bg-green-600"
                    onClick={handleLogin}
                  >
                    Инвестировать
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold mb-4 text-crypto-gold">Почему выбирают нас?</h2>
            <p className="text-slate-300 text-lg">Надежность, безопасность и стабильный доход</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            <Card className="bg-slate-800 border-slate-700">
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-crypto-green/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Shield className="h-8 w-8 text-crypto-green" />
                </div>
                <h3 className="text-xl font-semibold text-crypto-green mb-4">Безопасность</h3>
                <p className="text-slate-400">Ваши инвестиции защищены современными технологиями шифрования и многоуровневой системой безопасности.</p>
              </CardContent>
            </Card>

            <Card className="bg-slate-800 border-slate-700">
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-crypto-gold/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Clock className="h-8 w-8 text-crypto-gold" />
                </div>
                <h3 className="text-xl font-semibold text-crypto-gold mb-4">Ежедневные выплаты</h3>
                <p className="text-slate-400">Получайте проценты каждый день. Автоматические выплаты прямо на ваш счет без задержек.</p>
              </CardContent>
            </Card>

            <Card className="bg-slate-800 border-slate-700">
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-blue-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Award className="h-8 w-8 text-blue-400" />
                </div>
                <h3 className="text-xl font-semibold text-blue-400 mb-4">Высокая доходность</h3>
                <p className="text-slate-400">Стабильный доход от 1.2% до 2.2% в день. Реинвестирование прибыли для увеличения дохода.</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
