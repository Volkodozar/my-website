import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Copy, QrCode, Bitcoin, DollarSign } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

export default function Deposit() {
  const { user } = useAuth();
  const [selectedCrypto, setSelectedCrypto] = useState("BTC");
  const [amount, setAmount] = useState("");
  const [depositAddress, setDepositAddress] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const cryptoOptions = [
    { value: "BTC", label: "Bitcoin (BTC)", address: "bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh" },
    { value: "ETH", label: "Ethereum (ETH)", address: "0x742d35Cc6634C0532925a3b8D40c7b984d5f1c8e" },
    { value: "USDT", label: "USDT (TRC20)", address: "TLa2f6VPqDgRE67v1736s7bJ8Ray5wYjU7" },
    { value: "LTC", label: "Litecoin (LTC)", address: "ltc1qw4psxtqph7jq5x3nxkrq8w3v9zpqvpvmj5w8dg" }
  ];

  const selectedCryptoData = cryptoOptions.find(c => c.value === selectedCrypto);

  const generateDeposit = useMutation({
    mutationFn: (data: { amount: number; cryptoType: string }) =>
      apiRequest("POST", "/api/generate-deposit", data).then(res => res.json()),
    onSuccess: (data) => {
      setDepositAddress(data.address);
      toast({
        title: "Адрес создан",
        description: "Отправьте указанную сумму на данный адрес",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Ошибка",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleGenerateDeposit = () => {
    if (!amount || parseFloat(amount) <= 0) {
      toast({
        title: "Ошибка",
        description: "Укажите корректную сумму",
        variant: "destructive",
      });
      return;
    }

    // Для демо используем статический адрес
    setDepositAddress(selectedCryptoData?.address || "");
    toast({
      title: "Адрес создан",
      description: "Отправьте указанную сумму на данный адрес",
    });
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Скопировано",
      description: "Адрес скопирован в буфер обмена",
    });
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 p-4">
      <div className="max-w-2xl mx-auto py-12">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold mb-4 gradient-text">Пополнение баланса</h1>
          <p className="text-slate-300">Пополните баланс криптовалютой для начала инвестирования</p>
        </div>

        <Card className="bg-slate-800 border-slate-700 mb-6">
          <CardHeader>
            <CardTitle className="text-crypto-gold flex items-center">
              <DollarSign className="h-5 w-5 mr-2" />
              Текущий баланс
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-crypto-green">
              ${user ? parseFloat(user.balance || "0").toFixed(2) : "0.00"}
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-800 border-slate-700">
          <CardHeader>
            <CardTitle className="text-crypto-gold">Создать депозит</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <Label className="text-slate-300 mb-2">Криптовалюта</Label>
              <Select value={selectedCrypto} onValueChange={setSelectedCrypto}>
                <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-slate-700 border-slate-600">
                  {cryptoOptions.map((crypto) => (
                    <SelectItem key={crypto.value} value={crypto.value}>
                      {crypto.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label className="text-slate-300 mb-2">Сумма ($)</Label>
              <Input
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="50"
                min="5"
                className="bg-slate-700 border-slate-600 text-white focus:ring-crypto-green"
              />
              <div className="mt-1 text-sm text-slate-400">
                Минимальная сумма: $5
              </div>
            </div>

            <Button 
              onClick={handleGenerateDeposit}
              disabled={!amount}
              className="w-full bg-crypto-green hover:bg-green-600"
            >
              Создать депозит
            </Button>

            {depositAddress && (
              <div className="mt-6 p-4 bg-slate-900 rounded-lg border border-slate-600">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-crypto-gold font-semibold">Адрес для пополнения</h3>
                  <QrCode className="h-5 w-5 text-slate-400" />
                </div>
                
                <div className="space-y-3">
                  <div>
                    <div className="text-sm text-slate-400 mb-1">Сеть: {selectedCryptoData?.label}</div>
                    <div className="text-sm text-slate-400 mb-1">Сумма: ${amount}</div>
                  </div>
                  
                  <div className="flex items-center space-x-2 p-3 bg-slate-800 rounded border">
                    <Bitcoin className="h-4 w-4 text-crypto-gold" />
                    <code className="flex-1 text-sm font-mono text-slate-200 break-all">
                      {depositAddress}
                    </code>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => copyToClipboard(depositAddress)}
                      className="border-slate-600 hover:bg-slate-700"
                    >
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                  
                  <div className="text-xs text-slate-400 space-y-1">
                    <p>• Отправьте точную сумму ${amount} на указанный адрес</p>
                    <p>• Средства поступят автоматически после 3 подтверждений</p>
                    <p>• Обычно это занимает 10-30 минут</p>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}