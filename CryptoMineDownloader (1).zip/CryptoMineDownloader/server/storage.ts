import {
  users,
  investmentPlans,
  investments,
  transactions,
  investmentPayouts,
  type User,
  type UpsertUser,
  type InvestmentPlan,
  type InsertInvestmentPlan,
  type Investment,
  type InsertInvestment,
  type Transaction,
  type InsertTransaction,
  type InvestmentPayout,
  type InsertInvestmentPayout,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and } from "drizzle-orm";

export interface IStorage {
  // User operations (required for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  updateUserBalance(userId: string, amount: string): Promise<User>;
  updateUserStripeInfo(userId: string, customerId: string, subscriptionId?: string): Promise<User>;

  // Investment plan operations
  getInvestmentPlans(): Promise<InvestmentPlan[]>;
  getInvestmentPlan(id: number): Promise<InvestmentPlan | undefined>;
  createInvestmentPlan(plan: InsertInvestmentPlan): Promise<InvestmentPlan>;

  // Investment operations
  createInvestment(investment: InsertInvestment): Promise<Investment>;
  getInvestment(id: number): Promise<Investment | undefined>;
  getUserInvestments(userId: string): Promise<Investment[]>;
  updateInvestment(id: number, updates: Partial<Investment>): Promise<Investment>;
  getActiveInvestments(): Promise<Investment[]>;

  // Transaction operations
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
  getUserTransactions(userId: string, limit?: number): Promise<Transaction[]>;
  updateTransaction(id: number, updates: Partial<Transaction>): Promise<Transaction>;

  // Investment payout operations
  createInvestmentPayout(payout: InsertInvestmentPayout): Promise<InvestmentPayout>;
  getUserInvestmentPayouts(userId: string, limit?: number): Promise<InvestmentPayout[]>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async updateUserBalance(userId: string, amount: string): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ 
        balance: amount,
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  async updateUserStripeInfo(userId: string, customerId: string, subscriptionId?: string): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ 
        stripeCustomerId: customerId,
        stripeSubscriptionId: subscriptionId,
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  // Investment plan operations
  async getInvestmentPlans(): Promise<InvestmentPlan[]> {
    return await db
      .select()
      .from(investmentPlans)
      .where(eq(investmentPlans.isActive, true))
      .orderBy(investmentPlans.minAmount);
  }

  async getInvestmentPlan(id: number): Promise<InvestmentPlan | undefined> {
    const [plan] = await db
      .select()
      .from(investmentPlans)
      .where(eq(investmentPlans.id, id));
    return plan;
  }

  async createInvestmentPlan(plan: InsertInvestmentPlan): Promise<InvestmentPlan> {
    const [createdPlan] = await db
      .insert(investmentPlans)
      .values(plan)
      .returning();
    return createdPlan;
  }

  // Investment operations
  async createInvestment(investment: InsertInvestment): Promise<Investment> {
    const [createdInvestment] = await db
      .insert(investments)
      .values(investment)
      .returning();
    return createdInvestment;
  }

  async getInvestment(id: number): Promise<Investment | undefined> {
    const [investment] = await db
      .select()
      .from(investments)
      .where(eq(investments.id, id));
    return investment;
  }

  async getUserInvestments(userId: string): Promise<Investment[]> {
    return await db
      .select()
      .from(investments)
      .where(eq(investments.userId, userId))
      .orderBy(desc(investments.createdAt));
  }

  async updateInvestment(id: number, updates: Partial<Investment>): Promise<Investment> {
    const [investment] = await db
      .update(investments)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(investments.id, id))
      .returning();
    return investment;
  }

  async getActiveInvestments(): Promise<Investment[]> {
    return await db
      .select()
      .from(investments)
      .where(eq(investments.status, "active"));
  }

  // Transaction operations
  async createTransaction(transaction: InsertTransaction): Promise<Transaction> {
    const [createdTransaction] = await db
      .insert(transactions)
      .values(transaction)
      .returning();
    return createdTransaction;
  }

  async getUserTransactions(userId: string, limit: number = 10): Promise<Transaction[]> {
    return await db
      .select()
      .from(transactions)
      .where(eq(transactions.userId, userId))
      .orderBy(desc(transactions.createdAt))
      .limit(limit);
  }

  async updateTransaction(id: number, updates: Partial<Transaction>): Promise<Transaction> {
    const [transaction] = await db
      .update(transactions)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(transactions.id, id))
      .returning();
    return transaction;
  }

  // Investment payout operations
  async createInvestmentPayout(payout: InsertInvestmentPayout): Promise<InvestmentPayout> {
    const [createdPayout] = await db
      .insert(investmentPayouts)
      .values(payout)
      .returning();
    return createdPayout;
  }

  async getUserInvestmentPayouts(userId: string, limit: number = 10): Promise<InvestmentPayout[]> {
    return await db
      .select()
      .from(investmentPayouts)
      .where(eq(investmentPayouts.userId, userId))
      .orderBy(desc(investmentPayouts.createdAt))
      .limit(limit);
  }
}

export const storage = new DatabaseStorage();
