import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { insertTransactionSchema, insertInvestmentSchema } from "@shared/schema";
import { z } from "zod";

// Investment plans data
const INVESTMENT_PLANS = [
  {
    id: 1,
    name: "Стартовый",
    minAmount: 50,
    maxAmount: 499,
    dailyPercent: 1.2,
    termDays: 30,
    description: "Идеальный план для начинающих инвесторов",
  },
  {
    id: 2,
    name: "Стандартный",
    minAmount: 500,
    maxAmount: 2499,
    dailyPercent: 1.5,
    termDays: 45,
    description: "Сбалансированная доходность для средних инвестиций",
  },
  {
    id: 3,
    name: "Премиум",
    minAmount: 2500,
    maxAmount: 9999,
    dailyPercent: 1.8,
    termDays: 60,
    description: "Высокая доходность для крупных инвестиций",
  },
  {
    id: 4,
    name: "VIP",
    minAmount: 10000,
    maxAmount: 50000,
    dailyPercent: 2.2,
    termDays: 90,
    description: "Максимальная доходность для VIP инвесторов",
  },
];

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Investment plans
  app.get("/api/investment-plans", async (req, res) => {
    try {
      res.json(INVESTMENT_PLANS);
    } catch (error: any) {
      res.status(500).json({ message: "Error fetching investment plans: " + error.message });
    }
  });

  // Create investment
  app.post("/api/investments", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { planId, amount } = req.body;

      const plan = INVESTMENT_PLANS.find(p => p.id === planId);
      if (!plan) {
        return res.status(400).json({ message: "Investment plan not found" });
      }

      if (amount < plan.minAmount || amount > plan.maxAmount) {
        return res.status(400).json({ 
          message: `Amount must be between $${plan.minAmount} and $${plan.maxAmount}` 
        });
      }

      const user = await storage.getUser(userId);
      if (!user || parseFloat(user.balance) < amount) {
        return res.status(400).json({ message: "Insufficient balance" });
      }

      // Create investment
      const expiresAt = new Date();
      expiresAt.setDate(expiresAt.getDate() + plan.termDays);

      const investment = await storage.createInvestment({
        userId,
        planId,
        amount: amount.toString(),
        dailyPercent: plan.dailyPercent.toString(),
        termDays: plan.termDays,
        expiresAt,
      });

      // Deduct from user balance
      const newBalance = (parseFloat(user.balance) - amount).toString();
      await storage.updateUserBalance(userId, newBalance);

      // Create transaction record
      await storage.createTransaction({
        userId,
        type: "investment",
        amount: amount.toString(),
        currency: "USD",
        status: "completed",
        description: `Investment in ${plan.name} plan`,
      });

      res.json(investment);
    } catch (error: any) {
      res.status(500).json({ message: "Error creating investment: " + error.message });
    }
  });

  // Get user investments
  app.get("/api/investments", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const investments = await storage.getUserInvestments(userId);
      res.json(investments);
    } catch (error: any) {
      res.status(500).json({ message: "Error fetching investments: " + error.message });
    }
  });

  // Calculate investment profit
  app.post("/api/calculate-investment", async (req, res) => {
    try {
      const { planId, amount } = req.body;
      
      const plan = INVESTMENT_PLANS.find(p => p.id === planId);
      if (!plan) {
        return res.status(400).json({ message: "Investment plan not found" });
      }

      const dailyProfit = (amount * plan.dailyPercent) / 100;
      const totalProfit = dailyProfit * plan.termDays;
      const totalReturn = amount + totalProfit;

      res.json({
        dailyProfit: dailyProfit.toFixed(2),
        totalProfit: totalProfit.toFixed(2),
        totalReturn: totalReturn.toFixed(2),
        roi: ((totalProfit / amount) * 100).toFixed(2),
      });
    } catch (error: any) {
      res.status(500).json({ message: "Error calculating investment: " + error.message });
    }
  });

  // Transaction routes
  app.get("/api/transactions", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const limit = parseInt(req.query.limit as string) || 10;
      const transactions = await storage.getUserTransactions(userId, limit);
      res.json(transactions);
    } catch (error: any) {
      res.status(500).json({ message: "Error fetching transactions: " + error.message });
    }
  });

  // Create payment intent (requires Stripe keys)
  app.post("/api/create-payment-intent", isAuthenticated, async (req: any, res) => {
    if (!process.env.STRIPE_SECRET_KEY) {
      return res.status(500).json({ 
        message: "Stripe not configured. Please contact administrator." 
      });
    }

    try {
      const Stripe = require('stripe');
      const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
      
      const userId = req.user.claims.sub;
      const { amount } = req.body;
      
      if (!amount || amount < 1) {
        return res.status(400).json({ message: "Invalid amount" });
      }

      const paymentIntent = await stripe.paymentIntents.create({
        amount: Math.round(amount * 100), // Convert to cents
        currency: "usd",
        metadata: {
          userId,
          type: "deposit",
        },
      });

      // Create pending transaction
      await storage.createTransaction({
        userId,
        type: "deposit",
        amount: amount.toString(),
        currency: "USD",
        status: "pending",
        stripePaymentIntentId: paymentIntent.id,
        description: "Account deposit via Stripe",
      });

      res.json({ clientSecret: paymentIntent.client_secret });
    } catch (error: any) {
      res.status(500).json({ message: "Error creating payment intent: " + error.message });
    }
  });

  // Withdrawal request
  app.post("/api/withdraw", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { amount, method } = req.body;

      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      if (parseFloat(user.balance) < amount) {
        return res.status(400).json({ message: "Insufficient balance" });
      }

      if (amount < 50) {
        return res.status(400).json({ message: "Minimum withdrawal amount is $50" });
      }

      // Create withdrawal transaction
      await storage.createTransaction({
        userId,
        type: "withdrawal",
        amount: amount.toString(),
        currency: "USD",
        status: "pending",
        description: `Withdrawal via ${method}`,
        metadata: { method },
      });

      // Update user balance
      const newBalance = (parseFloat(user.balance) - amount).toString();
      await storage.updateUserBalance(userId, newBalance);

      res.json({ message: "Withdrawal request submitted successfully" });
    } catch (error: any) {
      res.status(500).json({ message: "Error processing withdrawal: " + error.message });
    }
  });

  // Investment statistics
  app.get("/api/investment-stats", async (req, res) => {
    try {
      // Return mock aggregated stats - in production these would be calculated from real data
      res.json({
        totalInvestors: 12847,
        totalInvested: 8247893,
        totalPaidOut: 1247893,
        averageROI: 18.5,
      });
    } catch (error: any) {
      res.status(500).json({ message: "Error fetching investment stats: " + error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}